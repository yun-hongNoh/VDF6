# CASE-02 — SCAMPER 실전

상태: **PARTIAL GOLDEN**

기존 VDF 6.0 field test의 근거 강의다. 초기 5블록/4이미지 관측은 규칙 개선 이전 결과도 섞여 있으므로 strict 정답으로 사용하지 않는다. 대신 N+1 기준점, same-form, scale, branded, 분류 경계, element cap/split 같은 이미 검증된 규칙을 회귀 검증한다.
